import { createFileRoute } from "@tanstack/react-router";
import { LegacyPage } from "@/components/LegacyPage";
import html from "@/legacy-pages/index7.html?raw";

export const Route = createFileRoute("/index7")({
  head: () => ({ meta: [
    { title: "Broadband Plans — Neo Broadband Variant 7" },
    { name: "description", content: "Neo Broadband high-speed Australian fibre plan options." },
    { property: "og:title", content: "Broadband Plans — Neo Broadband Variant 7" },
    { property: "og:description", content: "Neo Broadband high-speed Australian fibre plan options." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: () => <LegacyPage html={html} />,
});