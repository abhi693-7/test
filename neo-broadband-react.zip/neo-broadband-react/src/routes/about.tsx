import { createFileRoute } from "@tanstack/react-router";
import { LegacyPage } from "@/components/LegacyPage";
import html from "@/legacy-pages/about.html?raw";

export const Route = createFileRoute("/about")({
  head: () => ({ meta: [
    { title: "About Us — Neo Broadband" },
    { name: "description", content: "Learn about Neo Broadband and our Australian fibre network." },
    { property: "og:title", content: "About Us — Neo Broadband" },
    { property: "og:description", content: "Learn about Neo Broadband and our Australian fibre network." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: () => <LegacyPage html={html} />,
});