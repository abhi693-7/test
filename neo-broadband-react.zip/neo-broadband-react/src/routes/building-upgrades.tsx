import { createFileRoute } from "@tanstack/react-router";
import { LegacyPage } from "@/components/LegacyPage";
import html from "@/legacy-pages/building-upgrades.html?raw";

export const Route = createFileRoute("/building-upgrades")({
  head: () => ({ meta: [
    { title: "Building Upgrades — Neo Broadband" },
    { name: "description", content: "Upgrade apartment buildings and developments to full fibre." },
    { property: "og:title", content: "Building Upgrades — Neo Broadband" },
    { property: "og:description", content: "Upgrade apartment buildings and developments to full fibre." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: () => <LegacyPage html={html} />,
});