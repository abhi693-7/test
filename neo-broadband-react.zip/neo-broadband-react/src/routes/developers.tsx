import { createFileRoute } from "@tanstack/react-router";
import { LegacyPage } from "@/components/LegacyPage";
import html from "@/legacy-pages/developers.html?raw";

export const Route = createFileRoute("/developers")({
  head: () => ({ meta: [
    { title: "For Developers — Neo Broadband" },
    { name: "description", content: "Connectivity solutions for developers and new Australian properties." },
    { property: "og:title", content: "For Developers — Neo Broadband" },
    { property: "og:description", content: "Connectivity solutions for developers and new Australian properties." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: () => <LegacyPage html={html} />,
});