import { createFileRoute } from "@tanstack/react-router";
import { LegacyPage } from "@/components/LegacyPage";
import html from "@/legacy-pages/index6.html?raw";

export const Route = createFileRoute("/index6")({
  head: () => ({ meta: [
    { title: "Broadband Plans — Neo Broadband Variant 6" },
    { name: "description", content: "Neo Broadband residential, business, and enterprise plans." },
    { property: "og:title", content: "Broadband Plans — Neo Broadband Variant 6" },
    { property: "og:description", content: "Neo Broadband residential, business, and enterprise plans." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: () => <LegacyPage html={html} />,
});