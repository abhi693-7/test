import { createFileRoute } from "@tanstack/react-router";
import { LegacyPage } from "@/components/LegacyPage";
import html from "@/legacy-pages/payment.html?raw";

export const Route = createFileRoute("/payment")({
  head: () => ({ meta: [
    { title: "Secure Checkout — Neo Broadband" },
    { name: "description", content: "Complete your Neo Broadband plan payment securely." },
    { property: "og:title", content: "Secure Checkout — Neo Broadband" },
    { property: "og:description", content: "Complete your Neo Broadband plan payment securely." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: () => <LegacyPage html={html} />,
});