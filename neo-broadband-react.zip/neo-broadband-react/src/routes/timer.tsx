import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/timer")({
  head: () => ({ meta: [
    { title: "Timer — Neo Broadband" },
    { name: "description", content: "Open the linked timer service." },
    { property: "og:title", content: "Timer — Neo Broadband" },
    { property: "og:description", content: "Open the linked timer service." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: TimerRedirect,
});

function TimerRedirect() {
  useEffect(() => { window.location.replace("https://www.timermo.com"); }, []);
  return null;
}