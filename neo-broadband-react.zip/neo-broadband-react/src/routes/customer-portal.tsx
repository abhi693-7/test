import { createFileRoute } from "@tanstack/react-router";
import { LegacyPage } from "@/components/LegacyPage";
import html from "@/legacy-pages/customer-portal.html?raw";

export const Route = createFileRoute("/customer-portal")({
  head: () => ({ meta: [
    { title: "Customer Portal — Neo Broadband" },
    { name: "description", content: "Manage your Neo Broadband connection, plans, usage, and bills." },
    { property: "og:title", content: "Customer Portal — Neo Broadband" },
    { property: "og:description", content: "Manage your Neo Broadband connection, plans, usage, and bills." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: () => <LegacyPage html={html} />,
});