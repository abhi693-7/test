import { createFileRoute } from "@tanstack/react-router";
import { LegacyPage } from "@/components/LegacyPage";
import html from "@/legacy-pages/invoice.html?raw";

export const Route = createFileRoute("/invoice")({
  head: () => ({ meta: [
    { title: "Tax Invoice — Neo Broadband" },
    { name: "description", content: "View and download your Neo Broadband tax invoice." },
    { property: "og:title", content: "Tax Invoice — Neo Broadband" },
    { property: "og:description", content: "View and download your Neo Broadband tax invoice." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: () => <LegacyPage html={html} />,
});