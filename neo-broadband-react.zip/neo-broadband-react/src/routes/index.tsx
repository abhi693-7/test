import { createFileRoute } from "@tanstack/react-router";
import { LegacyPage } from "@/components/LegacyPage";
import html from "@/legacy-pages/index.html?raw";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Neo Broadband — High-Speed Broadband Plans" },
      { name: "description", content: "Fast, reliable fibre broadband plans for Australian homes and businesses." },
      { property: "og:title", content: "Neo Broadband — High-Speed Broadband Plans" },
      { property: "og:description", content: "Fast, reliable fibre broadband plans for Australian homes and businesses." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <LegacyPage html={html} />,
});