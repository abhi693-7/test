import { createFileRoute } from "@tanstack/react-router";
import { LegacyPage } from "@/components/LegacyPage";
import html from "@/legacy-pages/admin-portal.html?raw";

export const Route = createFileRoute("/admin-portal")({
  head: () => ({ meta: [
    { title: "Admin NOC & Operations Console — Neo Broadband" },
    { name: "description", content: "Neo Broadband network operations and subscriber administration console." },
    { property: "og:title", content: "Admin NOC & Operations Console — Neo Broadband" },
    { property: "og:description", content: "Neo Broadband network operations and subscriber administration console." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: () => <LegacyPage html={html} />,
});