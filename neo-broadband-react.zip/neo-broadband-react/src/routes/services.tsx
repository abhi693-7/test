import { createFileRoute } from "@tanstack/react-router";
import { LegacyPage } from "@/components/LegacyPage";
import html from "@/legacy-pages/services.html?raw";

export const Route = createFileRoute("/services")({
  head: () => ({ meta: [
    { title: "Our Services — Neo Broadband" },
    { name: "description", content: "Explore fibre, wireless, voice, and managed connectivity solutions." },
    { property: "og:title", content: "Our Services — Neo Broadband" },
    { property: "og:description", content: "Explore fibre, wireless, voice, and managed connectivity solutions." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: () => <LegacyPage html={html} />,
});