import { createFileRoute } from "@tanstack/react-router";
import { LegacyPage } from "@/components/LegacyPage";
import html from "@/legacy-pages/contact.html?raw";

export const Route = createFileRoute("/contact")({
  head: () => ({ meta: [
    { title: "Contact Us — Neo Broadband" },
    { name: "description", content: "Contact Neo Broadband for support, sales, and connectivity enquiries." },
    { property: "og:title", content: "Contact Us — Neo Broadband" },
    { property: "og:description", content: "Contact Neo Broadband for support, sales, and connectivity enquiries." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: () => <LegacyPage html={html} />,
});