import { useEffect, useMemo } from "react";
import { useRouter } from "@tanstack/react-router";

type LegacyPageProps = {
  html: string;
};

const pageRoutes: Record<string, string> = {
  "index.html": "/",
  "about.html": "/about",
  "services.html": "/services",
  "developers.html": "/developers",
  "building-upgrades.html": "/building-upgrades",
  "contact.html": "/contact",
  "customer-portal.html": "/customer-portal",
  "admin-portal.html": "/admin-portal",
  "invoice.html": "/invoice",
  "payment.html": "/payment",
  "index6.html": "/index6",
  "index7.html": "/index7",
  "timer.html": "/timer",
};

function rewriteLegacyUrls(markup: string) {
  let result = markup
    .replaceAll('src="images/', 'src="/images/')
    .replaceAll("src='images/", "src='/images/")
    .replaceAll('href="images/', 'href="/images/')
    .replaceAll("href='images/", "href='/images/");

  for (const [file, route] of Object.entries(pageRoutes)) {
    result = result.replaceAll(`href="${file}`, `href="${route}`);
    result = result.replaceAll(`href='${file}`, `href='${route}`);
  }

  return result;
}

function parseLegacyDocument(html: string) {
  const body = html.match(/<body[^>]*>([\s\S]*?)<\/body>/i)?.[1] ?? "";
  const styles = [...html.matchAll(/<style[^>]*>([\s\S]*?)<\/style>/gi)].map(
    (match) => match[1] ?? "",
  );
  const scripts = [...html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/gi)]
    .map((match) => ({
      code: match[2] ?? "",
      src: (match[1] ?? "").match(/src=["']([^"']+)["']/i)?.[1],
      type: (match[1] ?? "").match(/type=["']([^"']+)["']/i)?.[1],
    }))
    .filter(
      (script) =>
        !script.code.includes("YOUR_PROJECT") &&
        !script.src?.includes("@supabase/supabase-js"),
    );

  return {
    body: rewriteLegacyUrls(body.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")),
    styles,
    scripts,
  };
}

export function LegacyPage({ html }: LegacyPageProps) {
  const router = useRouter();
  const page = useMemo(() => parseLegacyDocument(html), [html]);

  useEffect(() => {
    const createdScripts: HTMLScriptElement[] = [];

    for (const legacyScript of page.scripts) {
      const script = document.createElement("script");
      if (legacyScript.type) script.type = legacyScript.type;
      if (legacyScript.src) {
        script.src = legacyScript.src.startsWith("http")
          ? legacyScript.src
          : `/${legacyScript.src.replace(/^\.\//, "")}`;
      } else {
        script.textContent = legacyScript.code;
      }
      document.body.appendChild(script);
      createdScripts.push(script);
    }

    const handleNavigation = (event: MouseEvent) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      const anchor = target.closest("a");
      const href = anchor?.getAttribute("href");
      if (!anchor || !href || href.startsWith("#") || href.startsWith("http")) return;
      if (!href.startsWith("/")) return;

      event.preventDefault();
      window.location.assign(href);
    };

    document.addEventListener("click", handleNavigation);
    return () => {
      document.removeEventListener("click", handleNavigation);
      for (const script of createdScripts) script.remove();
    };
  }, [page.scripts, router]);

  return (
    <>
      {page.styles.map((css, index) => (
        <style key={index} dangerouslySetInnerHTML={{ __html: css }} />
      ))}
      <div dangerouslySetInnerHTML={{ __html: page.body }} />
    </>
  );
}